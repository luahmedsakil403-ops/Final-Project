package com.example.shop_hub

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
